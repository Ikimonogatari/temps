import DownloadContent from "@/components/Download/DownloadContent";

export default function DownloadPage() {
  return (
    <>
      <DownloadContent />
    </>
  );
}
