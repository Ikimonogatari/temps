import ComingSoonContent from "@/components/ComingSoon/ComingSoonContent";

export default function ComingSoonPage() {
  return (
    <>
      <ComingSoonContent />
    </>
  );
}
