"use client";

import Custom404 from '@/components/Error/Custom404';
 
export default function NotFoundPage() {
  return (
    <>
      <Custom404 />
    </>
  )
}