import ThankYouContent from "@/components/ThankYou/ThankYouContent";

export default function ThankYouPage() {
  return (
    <>
      <ThankYouContent />
    </>
  );
}
