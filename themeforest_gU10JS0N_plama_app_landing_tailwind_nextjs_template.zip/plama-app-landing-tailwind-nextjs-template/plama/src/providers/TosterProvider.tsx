"use client";
import React from "react";
import { Toaster } from "react-hot-toast";

const TosterProvider = () => {
	return <Toaster />;
};

export default TosterProvider;