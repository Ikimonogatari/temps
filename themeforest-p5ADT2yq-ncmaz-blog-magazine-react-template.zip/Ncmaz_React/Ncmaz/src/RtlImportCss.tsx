import React from "react";
import "./styles/__theme_rtl.scss";

const RtlImportCss = () => {
  return null;
};

export default RtlImportCss;
