export interface ListingGalleryImage {
  id: number;
  url: string;
}
